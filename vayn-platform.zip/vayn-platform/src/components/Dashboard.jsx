/**
 * VAYN — Module 1C: Role-Based Dashboard
 *
 * Renders one of two internal views depending on the authenticated user's Cognito Group:
 *
 *   Admin / Talent Manager → Full roster management table:
 *     • Editable measurement fields (height, bust, waist, hips)
 *     • Status dropdown (Active | On Hold | Pending Review)
 *     • Save triggers PUT /models/{modelId} → API Gateway → Lambda → DynamoDB
 *
 *   Scout → Write-only new-talent submission form:
 *     • POST /models → DynamoDB, status forced to "Pending Review"
 *
 * Props:
 *   role      {string}  — 'Admin' | 'Talent Manager' | 'Scout'
 *   apiBase   {string}  — API Gateway base URL
 *   authToken {string}  — Cognito ID/access token for Authorization header
 *   user      {object}  — Amplify getCurrentUser() result (for display name)
 *   onSignOut {fn}      — Callback to clear auth state and return to login
 */

import { useState, useEffect, useCallback } from "react";

/* ─── constants ───────────────────────────────────────────────── */

const STATUSES = ["Active", "On Hold", "Pending Review"];

const MEASUREMENT_FIELDS = [
  { key: "height_cm", label: "Height (cm)" },
  { key: "bust_cm",   label: "Bust (cm)"   },
  { key: "waist_cm",  label: "Waist (cm)"  },
  { key: "hips_cm",   label: "Hips (cm)"   },
];

/* ─── shared api helper ───────────────────────────────────────── */

function apiHeaders(token) {
  return {
    "Content-Type": "application/json",
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
  };
}

/* ═══════════════════════════════════════════════════════════════
   ADMIN / TALENT MANAGER — full management view
═══════════════════════════════════════════════════════════════ */

function ManagementRow({ model, apiBase, authToken, onSaved }) {
  /* local edits live here until saved */
  const [draft,   setDraft]   = useState({ ...model });
  const [saving,  setSaving]  = useState(false);
  const [saved,   setSaved]   = useState(false);
  const [rowErr,  setRowErr]  = useState(null);

  function fieldChange(key, val) {
    setSaved(false);
    setDraft((d) => ({ ...d, [key]: val }));
  }

  async function handleSave() {
    setSaving(true);
    setRowErr(null);
    setSaved(false);
    try {
      const res = await fetch(`${apiBase}/models/${draft.modelId}`, {
        method: "PUT",
        headers: apiHeaders(authToken),
        body: JSON.stringify({
          status:    draft.status,
          height_cm: Number(draft.height_cm),
          bust_cm:   Number(draft.bust_cm),
          waist_cm:  Number(draft.waist_cm),
          hips_cm:   Number(draft.hips_cm),
        }),
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      setSaved(true);
      onSaved?.(draft);
    } catch (e) {
      setRowErr(e.message);
    } finally {
      setSaving(false);
    }
  }

  const dirty = JSON.stringify(draft) !== JSON.stringify(model);

  /* status badge colour */
  const badgeClass = {
    Active:           "text-emerald-400/80 border-emerald-400/20",
    "On Hold":        "text-amber-400/80  border-amber-400/20",
    "Pending Review": "text-white/40      border-white/10",
  }[draft.status] ?? "text-white/30 border-white/10";

  return (
    <tr className="border-b border-white/5 hover:bg-white/[0.02] transition-colors">
      {/* name */}
      <td className="py-4 pr-6 pl-2 text-[12px] tracking-wide text-white/70 whitespace-nowrap font-light w-44">
        {model.name}
      </td>

      {/* status dropdown */}
      <td className="pr-6 py-4">
        <select
          value={draft.status}
          onChange={(e) => fieldChange("status", e.target.value)}
          className={`
            bg-transparent border text-[10px] tracking-[0.15em] uppercase
            py-1.5 px-2 rounded-none outline-none cursor-pointer
            ${badgeClass}
          `}
        >
          {STATUSES.map((s) => (
            <option key={s} value={s} className="bg-[#111] text-white/70">
              {s}
            </option>
          ))}
        </select>
      </td>

      {/* measurement inputs */}
      {MEASUREMENT_FIELDS.map(({ key }) => (
        <td key={key} className="pr-4 py-4">
          <input
            type="number"
            value={draft[key] ?? ""}
            onChange={(e) => fieldChange(key, e.target.value)}
            className="w-16 bg-transparent border-b border-white/10 text-[12px]
                       text-white/60 text-right py-1 outline-none
                       focus:border-white/30 transition-colors
                       [appearance:textfield]
                       [&::-webkit-inner-spin-button]:appearance-none"
          />
        </td>
      ))}

      {/* save / status */}
      <td className="py-4 pl-2 text-right">
        {rowErr && (
          <span className="text-[10px] text-red-400/60 mr-3">{rowErr}</span>
        )}
        {saved && !dirty && (
          <span className="text-[10px] tracking-widest uppercase text-emerald-400/50 mr-3">
            Saved
          </span>
        )}
        <button
          onClick={handleSave}
          disabled={saving || !dirty}
          className={`
            text-[9px] tracking-[0.25em] uppercase px-4 py-2 border
            transition-all duration-200
            ${dirty && !saving
              ? "border-white/30 text-white/70 hover:bg-white hover:text-black"
              : "border-white/5 text-white/15 cursor-not-allowed"
            }
          `}
        >
          {saving ? "Saving…" : "Save"}
        </button>
      </td>
    </tr>
  );
}

function ManagementView({ apiBase, authToken }) {
  const [models,  setModels]  = useState([]);
  const [loading, setLoading] = useState(true);
  const [error,   setError]   = useState(null);

  const load = useCallback(() => {
    setLoading(true);
    fetch(`${apiBase}/models`, { headers: apiHeaders(authToken) })
      .then((r) => {
        if (!r.ok) throw new Error(`HTTP ${r.status}`);
        return r.json();
      })
      .then((d) => setModels(d.items ?? d))
      .catch((e) => setError(e.message))
      .finally(() => setLoading(false));
  }, [apiBase, authToken]);

  useEffect(load, [load]);

  const handleSaved = useCallback((updated) => {
    setModels((prev) =>
      prev.map((m) => (m.modelId === updated.modelId ? { ...m, ...updated } : m))
    );
  }, []);

  /* counts */
  const counts = models.reduce((acc, m) => {
    acc[m.status] = (acc[m.status] ?? 0) + 1;
    return acc;
  }, {});

  return (
    <div>
      {/* summary pills */}
      <div className="flex gap-6 mb-10 flex-wrap">
        {STATUSES.map((s) => (
          <div key={s} className="flex flex-col gap-1">
            <span className="text-[28px] font-thin tabular-nums text-white/80">
              {counts[s] ?? 0}
            </span>
            <span className="text-[9px] tracking-[0.25em] uppercase text-white/25">
              {s}
            </span>
          </div>
        ))}
      </div>

      {loading && (
        <p className="text-[11px] tracking-[0.2em] uppercase text-white/20 animate-pulse py-12">
          Loading roster…
        </p>
      )}

      {error && (
        <p className="text-[11px] text-red-400/50 py-12">{error}</p>
      )}

      {!loading && !error && (
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-white/10">
                <th className="pb-3 pl-2 pr-6 text-[9px] tracking-[0.3em] uppercase text-white/20 font-normal">
                  Name
                </th>
                <th className="pb-3 pr-6 text-[9px] tracking-[0.3em] uppercase text-white/20 font-normal">
                  Status
                </th>
                {MEASUREMENT_FIELDS.map(({ key, label }) => (
                  <th
                    key={key}
                    className="pb-3 pr-4 text-[9px] tracking-[0.3em] uppercase text-white/20 font-normal text-right"
                  >
                    {label}
                  </th>
                ))}
                <th className="pb-3" />
              </tr>
            </thead>
            <tbody>
              {models.map((m) => (
                <ManagementRow
                  key={m.modelId}
                  model={m}
                  apiBase={apiBase}
                  authToken={authToken}
                  onSaved={handleSaved}
                />
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════════
   SCOUT — write-only talent submission form
═══════════════════════════════════════════════════════════════ */

const EMPTY_SUBMISSION = {
  name:      "",
  height_cm: "",
  bust_cm:   "",
  waist_cm:  "",
  hips_cm:   "",
};

function ScoutView({ apiBase, authToken }) {
  const [form,       setForm]       = useState({ ...EMPTY_SUBMISSION });
  const [submitting, setSubmitting] = useState(false);
  const [submitted,  setSubmitted]  = useState(false);
  const [formErr,    setFormErr]    = useState(null);

  function change(key, val) {
    setSubmitted(false);
    setForm((f) => ({ ...f, [key]: val }));
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setFormErr(null);
    setSubmitting(true);

    const payload = {
      ...form,
      height_cm: Number(form.height_cm),
      bust_cm:   Number(form.bust_cm),
      waist_cm:  Number(form.waist_cm),
      hips_cm:   Number(form.hips_cm),
      status:    "Pending Review", // always forced
    };

    try {
      const res = await fetch(`${apiBase}/models`, {
        method: "POST",
        headers: apiHeaders(authToken),
        body: JSON.stringify(payload),
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      setForm({ ...EMPTY_SUBMISSION });
      setSubmitted(true);
    } catch (err) {
      setFormErr(err.message);
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="max-w-sm">
      <p className="text-[9px] tracking-[0.35em] uppercase text-white/20 mb-10">
        New Talent Submission
      </p>

      <form onSubmit={handleSubmit} noValidate className="space-y-0">
        {/* name */}
        <div className="border-b border-white/10">
          <input
            type="text"
            value={form.name}
            onChange={(e) => change("name", e.target.value)}
            placeholder="Full Name"
            required
            className="w-full bg-transparent text-white/70 text-[13px]
                       tracking-wide placeholder:text-white/15 py-4 outline-none font-light"
          />
        </div>

        {/* measurements */}
        <div className="grid grid-cols-2 gap-0">
          {MEASUREMENT_FIELDS.map(({ key, label }, i) => (
            <div
              key={key}
              className={`border-b border-white/10 ${i % 2 === 0 ? "pr-4" : ""}`}
            >
              <input
                type="number"
                value={form[key]}
                onChange={(e) => change(key, e.target.value)}
                placeholder={label}
                required
                min={0}
                className="w-full bg-transparent text-white/70 text-[13px]
                           tracking-wide placeholder:text-white/15 py-4 outline-none font-light
                           [appearance:textfield]
                           [&::-webkit-inner-spin-button]:appearance-none"
              />
            </div>
          ))}
        </div>

        {/* status note */}
        <p className="pt-5 pb-6 text-[9px] tracking-[0.2em] uppercase text-white/15">
          Status will be set to Pending Review
        </p>

        {/* feedback */}
        {formErr && (
          <p className="mb-4 text-[11px] text-red-400/60">{formErr}</p>
        )}
        {submitted && (
          <p className="mb-4 text-[11px] tracking-widest uppercase text-emerald-400/50">
            Submitted
          </p>
        )}

        <button
          type="submit"
          disabled={submitting}
          className={`
            w-full py-4 text-[10px] tracking-[0.35em] uppercase transition-all duration-300
            ${submitting
              ? "bg-white/5 text-white/15 cursor-not-allowed"
              : "bg-white text-black hover:bg-white/90 active:scale-[0.99]"
            }
          `}
        >
          {submitting ? "Submitting…" : "Submit Talent"}
        </button>
      </form>
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════════
   DASHBOARD SHELL (role router + nav)
═══════════════════════════════════════════════════════════════ */

export default function Dashboard({ role, user, apiBase, authToken, onSignOut }) {
  const displayName =
    user?.signInDetails?.loginId ??
    user?.username ??
    "User";

  const isManager = role === "Admin" || role === "Talent Manager";

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-white">

      {/* ── navigation ── */}
      <nav className="flex items-center justify-between px-8 py-5 border-b border-white/5">
        <img src="/assets/vayn-logo.svg" alt="VAYN" className="h-5 w-auto" />

        <div className="flex items-center gap-6">
          <span className="text-[9px] tracking-[0.2em] uppercase text-white/20">
            {role}
          </span>
          <span className="text-[9px] tracking-[0.1em] text-white/15">
            {displayName}
          </span>
          <button
            onClick={onSignOut}
            className="text-[9px] tracking-[0.2em] uppercase text-white/20
                       hover:text-white/50 transition-colors"
          >
            Sign Out
          </button>
        </div>
      </nav>

      {/* ── page header ── */}
      <div className="px-8 py-12 border-b border-white/5">
        <p className="text-[9px] tracking-[0.35em] uppercase text-white/20 mb-3">
          {isManager ? "Internal Management" : "Scout Portal"}
        </p>
        <h1 className="text-2xl sm:text-4xl font-thin tracking-widest uppercase text-white/80 leading-none">
          {isManager ? "Talent Roster" : "Log New Talent"}
        </h1>
      </div>

      {/* ── main content ── */}
      <main className="px-8 py-10">
        {role === "Unauthorized" && (
          <p className="text-[12px] tracking-wide text-red-400/50 py-16">
            Your account does not have an assigned role. Please contact an administrator.
          </p>
        )}

        {isManager && (
          <ManagementView apiBase={apiBase} authToken={authToken} />
        )}

        {role === "Scout" && (
          <ScoutView apiBase={apiBase} authToken={authToken} />
        )}
      </main>
    </div>
  );
}
