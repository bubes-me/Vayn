/**
 * VAYN — UserManagement.jsx
 *
 * Admin-only panel for managing Cognito users without touching the AWS console.
 * Calls a Lambda-backed API Gateway that wraps the Cognito Identity Provider SDK.
 *
 * Features:
 *   - List all users with their group, status, and email
 *   - Create a new user (sends Cognito invite email automatically)
 *   - Assign / change a user's group
 *   - Enable / disable a user
 *   - Delete a user
 *
 * Props:
 *   apiBase   {string}  — API Gateway base URL
 *   authToken {string}  — Cognito access token (Admin group required)
 */

import { useState, useEffect, useCallback } from "react";

const GROUPS = ["Admin", "Talent Manager", "Scout"];

function apiHeaders(token) {
  return {
    "Content-Type": "application/json",
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
  };
}

/* ─── empty form state ────────────────────────────────────────── */
const EMPTY_FORM = { email: "", group: "Scout", tempPassword: "" };

/* ─── user row ────────────────────────────────────────────────── */
function UserRow({ user, apiBase, authToken, onRefresh }) {
  const [busy,    setBusy]    = useState(false);
  const [rowErr,  setRowErr]  = useState(null);
  const [group,   setGroup]   = useState(user.group ?? "");

  async function call(path, method, body) {
    setBusy(true);
    setRowErr(null);
    try {
      const res = await fetch(`${apiBase}${path}`, {
        method,
        headers: apiHeaders(authToken),
        body: body ? JSON.stringify(body) : undefined,
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      onRefresh();
    } catch (e) {
      setRowErr(e.message);
    } finally {
      setBusy(false);
    }
  }

  async function handleGroupChange(newGroup) {
    setGroup(newGroup);
    await call(`/users/${encodeURIComponent(user.username)}/group`, "PUT", {
      oldGroup: user.group,
      newGroup,
    });
  }

  const isEnabled = user.enabled !== false;

  const statusClass = isEnabled
    ? "text-emerald-400/70 border-emerald-400/20"
    : "text-white/20 border-white/10";

  return (
    <tr className="border-b border-white/5 hover:bg-white/[0.02] transition-colors">
      {/* email */}
      <td className="py-4 pl-2 pr-6 text-[12px] font-light text-white/70 w-56 truncate">
        {user.email ?? user.username}
      </td>

      {/* group selector */}
      <td className="pr-6 py-4">
        <select
          value={group}
          onChange={(e) => handleGroupChange(e.target.value)}
          disabled={busy}
          className="bg-transparent border border-white/10 text-[10px]
                     tracking-[0.15em] uppercase text-white/50
                     py-1.5 px-2 outline-none cursor-pointer
                     disabled:opacity-30"
        >
          {GROUPS.map((g) => (
            <option key={g} value={g} className="bg-[#111] text-white/70">
              {g}
            </option>
          ))}
        </select>
      </td>

      {/* status badge */}
      <td className="pr-6 py-4">
        <span className={`text-[9px] tracking-[0.2em] uppercase border px-2 py-1 ${statusClass}`}>
          {isEnabled ? "Active" : "Disabled"}
        </span>
      </td>

      {/* actions */}
      <td className="py-4 text-right pr-2">
        <div className="flex items-center justify-end gap-3">
          {rowErr && (
            <span className="text-[10px] text-red-400/50">{rowErr}</span>
          )}

          {/* enable / disable toggle */}
          <button
            onClick={() =>
              call(
                `/users/${encodeURIComponent(user.username)}/${isEnabled ? "disable" : "enable"}`,
                "PUT"
              )
            }
            disabled={busy}
            className="text-[9px] tracking-[0.2em] uppercase text-white/25
                       hover:text-white/60 transition-colors disabled:opacity-20"
          >
            {isEnabled ? "Disable" : "Enable"}
          </button>

          {/* delete */}
          <button
            onClick={() => {
              if (confirm(`Delete ${user.email ?? user.username}? This cannot be undone.`)) {
                call(`/users/${encodeURIComponent(user.username)}`, "DELETE");
              }
            }}
            disabled={busy}
            className="text-[9px] tracking-[0.2em] uppercase text-red-400/30
                       hover:text-red-400/60 transition-colors disabled:opacity-20"
          >
            Delete
          </button>
        </div>
      </td>
    </tr>
  );
}

/* ─── create user form ────────────────────────────────────────── */
function CreateUserForm({ apiBase, authToken, onCreated }) {
  const [form,       setForm]       = useState({ ...EMPTY_FORM });
  const [submitting, setSubmitting] = useState(false);
  const [formErr,    setFormErr]    = useState(null);
  const [done,       setDone]       = useState(false);

  function change(k, v) {
    setDone(false);
    setForm((f) => ({ ...f, [k]: v }));
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setFormErr(null);
    setSubmitting(true);
    try {
      const res = await fetch(`${apiBase}/users`, {
        method: "POST",
        headers: apiHeaders(authToken),
        body: JSON.stringify(form),
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      setForm({ ...EMPTY_FORM });
      setDone(true);
      onCreated?.();
    } catch (e) {
      setFormErr(e.message);
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="max-w-sm">
      <p className="text-[9px] tracking-[0.35em] uppercase text-white/20 mb-6">
        New User
      </p>

      <form onSubmit={handleSubmit} noValidate className="space-y-0">
        <div className="border-b border-white/10">
          <input
            type="email"
            value={form.email}
            onChange={(e) => change("email", e.target.value)}
            placeholder="Email address"
            required
            className="w-full bg-transparent text-white/70 text-[13px]
                       tracking-wide placeholder:text-white/15 py-4 outline-none font-light"
          />
        </div>

        <div className="border-b border-white/10">
          <input
            type="text"
            value={form.tempPassword}
            onChange={(e) => change("tempPassword", e.target.value)}
            placeholder="Temporary password"
            required
            className="w-full bg-transparent text-white/70 text-[13px]
                       tracking-wide placeholder:text-white/15 py-4 outline-none font-light"
          />
        </div>

        <div className="border-b border-white/10">
          <select
            value={form.group}
            onChange={(e) => change("group", e.target.value)}
            className="w-full bg-transparent text-white/50 text-[11px]
                       tracking-[0.15em] uppercase py-4 outline-none cursor-pointer
                       border-none"
          >
            {GROUPS.map((g) => (
              <option key={g} value={g} className="bg-[#111] text-white/70">
                {g}
              </option>
            ))}
          </select>
        </div>

        <div className="pt-6">
          {formErr && (
            <p className="mb-4 text-[11px] text-red-400/60">{formErr}</p>
          )}
          {done && (
            <p className="mb-4 text-[11px] tracking-widest uppercase text-emerald-400/50">
              User created — invite sent
            </p>
          )}
          <button
            type="submit"
            disabled={submitting}
            className={`
              w-full py-4 text-[10px] tracking-[0.35em] uppercase transition-all duration-300
              ${submitting
                ? "bg-white/5 text-white/15 cursor-not-allowed"
                : "bg-white text-black hover:bg-white/90 active:scale-[0.99]"
              }
            `}
          >
            {submitting ? "Creating…" : "Create User"}
          </button>
        </div>
      </form>
    </div>
  );
}

/* ─── main export ─────────────────────────────────────────────── */
export default function UserManagement({ apiBase, authToken }) {
  const [users,   setUsers]   = useState([]);
  const [loading, setLoading] = useState(true);
  const [error,   setError]   = useState(null);
  const [tab,     setTab]     = useState("list"); // 'list' | 'create'

  const load = useCallback(() => {
    setLoading(true);
    fetch(`${apiBase}/users`, { headers: apiHeaders(authToken) })
      .then((r) => {
        if (!r.ok) throw new Error(`HTTP ${r.status}`);
        return r.json();
      })
      .then((d) => setUsers(d.users ?? d))
      .catch((e) => setError(e.message))
      .finally(() => setLoading(false));
  }, [apiBase, authToken]);

  useEffect(load, [load]);

  return (
    <div>
      {/* sub-tabs */}
      <div className="flex gap-8 mb-10 border-b border-white/5 pb-4">
        {["list", "create"].map((t) => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={`text-[9px] tracking-[0.3em] uppercase transition-colors
              ${tab === t ? "text-white/70" : "text-white/20 hover:text-white/40"}`}
          >
            {t === "list" ? "All Users" : "New User"}
          </button>
        ))}
      </div>

      {tab === "create" && (
        <CreateUserForm
          apiBase={apiBase}
          authToken={authToken}
          onCreated={() => { setTab("list"); load(); }}
        />
      )}

      {tab === "list" && (
        <>
          {loading && (
            <p className="text-[11px] tracking-[0.2em] uppercase text-white/20 animate-pulse py-12">
              Loading users…
            </p>
          )}
          {error && (
            <p className="text-[11px] text-red-400/50 py-12">{error}</p>
          )}
          {!loading && !error && (
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-white/10">
                    {["Email", "Group", "Status", ""].map((h) => (
                      <th key={h} className="pb-3 pl-2 pr-6 text-[9px] tracking-[0.3em] uppercase text-white/20 font-normal">
                        {h}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {users.map((u) => (
                    <UserRow
                      key={u.username}
                      user={u}
                      apiBase={apiBase}
                      authToken={authToken}
                      onRefresh={load}
                    />
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </>
      )}
    </div>
  );
}
