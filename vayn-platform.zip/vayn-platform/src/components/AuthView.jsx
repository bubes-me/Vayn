/**
 * VAYN — Module 1A: Cognito Authentication View
 *
 * Authenticates against Amazon Cognito using the hosted UI flow
 * or direct SRP via aws-amplify. Extracts the user's Cognito Group
 * ('Admin' | 'Talent Manager' | 'Scout') from the JWT access token
 * and passes it up via onAuth(user, role).
 *
 * Dependencies: aws-amplify (v6)
 * Configure Amplify once in main.jsx before rendering.
 */

import { useState } from "react";
import { signIn, getCurrentUser, fetchAuthSession } from "aws-amplify/auth";

/* ─── helpers ─────────────────────────────────────────────────── */

/**
 * Decode the Cognito groups from an Amplify v6 session.
 * Groups live in the access token under `cognito:groups`.
 */
async function resolveUserRole() {
  const session = await fetchAuthSession();
  const payload = session.tokens?.accessToken?.payload ?? {};
  const groups = payload["cognito:groups"] ?? [];

  if (groups.includes("Admin")) return "Admin";
  if (groups.includes("Talent Manager")) return "Talent Manager";
  if (groups.includes("Scout")) return "Scout";
  return "Unauthorized";
}

/* ─── component ───────────────────────────────────────────────── */

/**
 * @param {{ onAuth: (user: object, role: string) => void }} props
 */
export default function AuthView({ onAuth }) {
  const [email, setEmail]       = useState("");
  const [password, setPassword] = useState("");
  const [error, setError]       = useState(null);
  const [loading, setLoading]   = useState(false);

  async function handleLogin(e) {
    e.preventDefault();
    setError(null);
    setLoading(true);

    try {
      await signIn({ username: email.trim(), password });
      const user = await getCurrentUser();
      const role = await resolveUserRole();
      onAuth(user, role);
    } catch (err) {
      setError(err.message ?? "Authentication failed.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen bg-[#0a0a0a] flex flex-col">
      {/* ── header ── */}
      <header className="flex items-center justify-center pt-16 pb-8">
        <img
          src="/assets/vayn-logo.jpg"
          alt="VAYN"
          className="h-8 w-auto opacity-90"
        />
      </header>

      {/* ── form card ── */}
      <main className="flex-1 flex items-start justify-center px-6">
        <div className="w-full max-w-sm">
          {/* thin rule above */}
          <div className="h-px bg-white/10 mb-10" />

          <p className="text-[10px] tracking-[0.3em] uppercase text-white/30 mb-8">
            Portal Access
          </p>

          <form onSubmit={handleLogin} noValidate className="space-y-0">
            {/* email */}
            <div className="border-b border-white/10">
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Email"
                required
                autoComplete="email"
                className={`
                  w-full bg-transparent text-white/80 text-[13px] tracking-wide
                  placeholder:text-white/20 py-4 outline-none
                  font-light
                `}
              />
            </div>

            {/* password */}
            <div className="border-b border-white/10 mb-8">
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Password"
                required
                autoComplete="current-password"
                className={`
                  w-full bg-transparent text-white/80 text-[13px] tracking-wide
                  placeholder:text-white/20 py-4 outline-none
                  font-light
                `}
              />
            </div>

            {/* error */}
            {error && (
              <p className="text-[11px] tracking-wide text-red-400/70 mb-6 -mt-4">
                {error}
              </p>
            )}

            {/* submit */}
            <button
              type="submit"
              disabled={loading}
              className={`
                w-full py-4 text-[10px] tracking-[0.35em] uppercase
                transition-all duration-300
                ${loading
                  ? "bg-white/5 text-white/20 cursor-not-allowed"
                  : "bg-white text-black hover:bg-white/90 active:scale-[0.99]"
                }
              `}
            >
              {loading ? "Authenticating…" : "Enter"}
            </button>
          </form>

          {/* thin rule below */}
          <div className="h-px bg-white/10 mt-10" />
        </div>
      </main>

      {/* ── footer ── */}
      <footer className="py-8 text-center">
        <p className="text-[9px] tracking-[0.25em] uppercase text-white/15">
          VAYN Talent Management · Private Access
        </p>
      </footer>
    </div>
  );
}
