/**
 * VAYN — Lambda Handler  (vayn-models-api/index.mjs)
 *
 * Routes REST calls from API Gateway to DynamoDB operations on 'VaynModels'.
 * Deploy this as a single Node 20.x Lambda and point all API Gateway routes at it.
 *
 * API Gateway resource mapping (proxy integration recommended):
 *
 *   GET    /models                 → list all models (Admin/TM) or Active only (Scout)
 *   GET    /models?status=Active   → public filtered list
 *   POST   /models                 → create new model (Scout: status forced to Pending Review)
 *   PUT    /models/{modelId}       → update status + measurements (Admin/TM only)
 *
 * IAM role for this Lambda needs:
 *   dynamodb:GetItem, PutItem, UpdateItem, Query, Scan on arn:.../VaynModels
 *
 * Environment variables:
 *   TABLE_NAME   — DynamoDB table name (default: VaynModels)
 *   AWS_REGION   — set automatically by Lambda runtime
 */

import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import {
  DynamoDBDocumentClient,
  ScanCommand,
  PutCommand,
  UpdateCommand,
} from "@aws-sdk/lib-dynamodb";
import { randomUUID } from "crypto";

const client   = new DynamoDBClient({});
const docClient = DynamoDBDocumentClient.from(client);
const TABLE    = process.env.TABLE_NAME ?? "VaynModels";

/* ─── helpers ─────────────────────────────────────────────────── */

function ok(body, status = 200) {
  return {
    statusCode: status,
    headers: cors(),
    body: JSON.stringify(body),
  };
}

function err(message, status = 400) {
  return {
    statusCode: status,
    headers: cors(),
    body: JSON.stringify({ error: message }),
  };
}

function cors() {
  return {
    "Content-Type": "application/json",
    "Access-Control-Allow-Origin":  "*",
    "Access-Control-Allow-Headers": "Content-Type,Authorization",
    "Access-Control-Allow-Methods": "GET,POST,PUT,OPTIONS",
  };
}

/**
 * Extract Cognito groups from the authorizer context injected by API Gateway
 * when a Cognito User Pool Authorizer is attached to the route.
 */
function getGroups(event) {
  try {
    const claims = event.requestContext?.authorizer?.claims ?? {};
    const raw    = claims["cognito:groups"] ?? "";
    return Array.isArray(raw) ? raw : raw.split(",").filter(Boolean);
  } catch {
    return [];
  }
}

function isManagerOrAdmin(groups) {
  return groups.includes("Admin") || groups.includes("Talent Manager");
}

/* ─── route handlers ──────────────────────────────────────────── */

async function listModels(event) {
  const groups      = getGroups(event);
  const statusFilter = event.queryStringParameters?.status;

  const params = { TableName: TABLE };

  /* Scouts see nothing via this endpoint (their UI is write-only) */
  if (!isManagerOrAdmin(groups) && !statusFilter) {
    return err("Forbidden", 403);
  }

  /* Filter by status if provided (used by public directory) */
  if (statusFilter) {
    params.FilterExpression    = "#s = :s";
    params.ExpressionAttributeNames  = { "#s": "status" };
    params.ExpressionAttributeValues = { ":s": statusFilter };
  }

  const result = await docClient.send(new ScanCommand(params));
  return ok({ items: result.Items });
}

async function createModel(event) {
  const groups = getGroups(event);
  const body   = JSON.parse(event.body ?? "{}");

  if (!body.name) return err("name is required");

  const isScout   = groups.includes("Scout");
  const isManager = isManagerOrAdmin(groups);

  if (!isScout && !isManager) return err("Forbidden", 403);

  const item = {
    modelId:   randomUUID(),
    name:      String(body.name).trim(),
    height_cm: Number(body.height_cm) || 0,
    bust_cm:   Number(body.bust_cm)   || 0,
    waist_cm:  Number(body.waist_cm)  || 0,
    hips_cm:   Number(body.hips_cm)   || 0,
    /* Scouts cannot set status — always forced to Pending Review */
    status:    isScout ? "Pending Review" : (body.status ?? "Pending Review"),
    profileImageId: body.profileImageId ?? null,
    createdAt: new Date().toISOString(),
  };

  await docClient.send(new PutCommand({ TableName: TABLE, Item: item }));
  return ok(item, 201);
}

async function updateModel(event) {
  const groups  = getGroups(event);
  if (!isManagerOrAdmin(groups)) return err("Forbidden", 403);

  const modelId = event.pathParameters?.modelId;
  if (!modelId) return err("modelId path parameter required");

  const body = JSON.parse(event.body ?? "{}");

  /* build a safe update expression — only update fields sent */
  const allowed = ["status", "height_cm", "bust_cm", "waist_cm", "hips_cm", "profileImageId"];
  const updates  = [];
  const names    = {};
  const values   = {};

  for (const field of allowed) {
    if (body[field] !== undefined) {
      const tok   = `#${field}`;
      const vtok  = `:${field}`;
      names[tok]  = field;
      values[vtok] = body[field];
      updates.push(`${tok} = ${vtok}`);
    }
  }

  if (updates.length === 0) return err("No valid fields to update");

  values[":updatedAt"] = new Date().toISOString();
  names["#updatedAt"]  = "updatedAt";
  updates.push("#updatedAt = :updatedAt");

  await docClient.send(
    new UpdateCommand({
      TableName:                 TABLE,
      Key:                       { modelId },
      UpdateExpression:          `SET ${updates.join(", ")}`,
      ExpressionAttributeNames:  names,
      ExpressionAttributeValues: values,
    })
  );

  return ok({ modelId, updated: true });
}

/* ─── entry point ─────────────────────────────────────────────── */

export async function handler(event) {
  /* CORS preflight */
  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 204, headers: cors(), body: "" };
  }

  try {
    const method   = event.httpMethod;
    const resource = event.resource ?? event.path ?? "";

    if (method === "GET"  && resource.includes("/models"))   return listModels(event);
    if (method === "POST" && resource.endsWith("/models"))   return createModel(event);
    if (method === "PUT"  && resource.includes("/models/"))  return updateModel(event);

    return err("Not Found", 404);
  } catch (e) {
    console.error(e);
    return err("Internal Server Error", 500);
  }
}
