/**
 * VAYN — Module 1B: Client-Facing Directory Grid
 *
 * Public roster of active models. Fetches from API Gateway (GET /models?status=Active).
 * Profile images are served via Google Drive's public thumbnail endpoint using
 * the stored `profileImageId` attribute — zero AWS data-transfer cost.
 *
 * Filter sliders operate entirely client-side after the initial fetch.
 *
 * Props:
 *   apiBase   {string}  — API Gateway base URL, e.g. https://xyz.execute-api.us-east-1.amazonaws.com/prod
 *   authToken {string?} — Optional Bearer token for authenticated fetches (leave null for public endpoint)
 */

import { useState, useEffect, useMemo } from "react";

/* ─── Drive image helper ──────────────────────────────────────── */

/**
 * Returns a Google Drive thumbnail URL.
 * For Drive files shared as "Anyone with link can view",
 * this endpoint returns a JPEG thumbnail without auth.
 * sz=w400 keeps bandwidth tiny while rendering sharp in the card grid.
 */
function driveThumb(fileId, size = 400) {
  return `https://drive.google.com/thumbnail?id=${fileId}&sz=w${size}`;
}

/* ─── sub-components ──────────────────────────────────────────── */

function FilterSlider({ label, unit, min, max, value, onChange }) {
  return (
    <div className="flex flex-col gap-1.5">
      <div className="flex items-baseline justify-between">
        <span className="text-[9px] tracking-[0.25em] uppercase text-white/30">
          {label}
        </span>
        <span className="text-[11px] font-light text-white/60 tabular-nums">
          ≥ {value}
          <span className="text-white/30 ml-0.5">{unit}</span>
        </span>
      </div>
      <input
        type="range"
        min={min}
        max={max}
        value={value}
        step={1}
        onChange={(e) => onChange(Number(e.target.value))}
        className="w-full appearance-none h-px bg-white/10 cursor-pointer
                   [&::-webkit-slider-thumb]:appearance-none
                   [&::-webkit-slider-thumb]:w-3
                   [&::-webkit-slider-thumb]:h-3
                   [&::-webkit-slider-thumb]:rounded-full
                   [&::-webkit-slider-thumb]:bg-white"
      />
    </div>
  );
}

function ModelCard({ model }) {
  const [imgError, setImgError] = useState(false);

  return (
    <article
      className="group relative overflow-hidden cursor-pointer"
      style={{ aspectRatio: "2/3" }}
    >
      {/* image */}
      <div className="absolute inset-0 bg-neutral-900">
        {model.profileImageId && !imgError ? (
          <img
            src={driveThumb(model.profileImageId)}
            alt={model.name}
            onError={() => setImgError(true)}
            className="w-full h-full object-cover object-top
                       transition-transform duration-700 ease-out
                       group-hover:scale-105"
            loading="lazy"
          />
        ) : (
          /* fallback placeholder */
          <div className="w-full h-full flex items-end justify-center pb-8">
            <span className="text-[9px] tracking-[0.2em] uppercase text-white/10">
              No Image
            </span>
          </div>
        )}
      </div>

      {/* gradient overlay */}
      <div
        className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/0 to-transparent
                   opacity-0 group-hover:opacity-100 transition-opacity duration-500"
      />

      {/* hover info panel */}
      <div
        className="absolute bottom-0 left-0 right-0 p-4
                   translate-y-2 opacity-0
                   group-hover:translate-y-0 group-hover:opacity-100
                   transition-all duration-500"
      >
        <p className="text-white text-[13px] tracking-wider font-light mb-1">
          {model.name}
        </p>
        <p className="text-white/40 text-[10px] tracking-[0.2em] uppercase">
          {model.height_cm} cm &nbsp;·&nbsp; {model.bust_cm}–{model.waist_cm}–{model.hips_cm}
        </p>
      </div>

      {/* permanent name below card */}
    </article>
  );
}

/* ─── main component ──────────────────────────────────────────── */

export default function DirectoryGrid({ apiBase, authToken = null }) {
  const [models,  setModels]  = useState([]);
  const [loading, setLoading] = useState(true);
  const [error,   setError]   = useState(null);

  /* filter state */
  const [minHeight, setMinHeight] = useState(165);
  const [minBust,   setMinBust]   = useState(80);
  const [minWaist,  setMinWaist]  = useState(55);

  /* fetch active roster */
  useEffect(() => {
    const headers = { "Content-Type": "application/json" };
    if (authToken) headers["Authorization"] = `Bearer ${authToken}`;

    fetch(`${apiBase}/models?status=Active`, { headers })
      .then((r) => {
        if (!r.ok) throw new Error(`HTTP ${r.status}`);
        return r.json();
      })
      .then((data) => setModels(data.items ?? data))
      .catch((e) => setError(e.message))
      .finally(() => setLoading(false));
  }, [apiBase, authToken]);

  /* client-side filter */
  const filtered = useMemo(() => {
    return models.filter((m) =>
      (m.height_cm ?? 0) >= minHeight &&
      (m.bust_cm   ?? 0) >= minBust   &&
      (m.waist_cm  ?? 0) >= minWaist
    );
  }, [models, minHeight, minBust, minWaist]);

  /* ── render ── */
  return (
    <div className="min-h-screen bg-[#0a0a0a] text-white">

      {/* ── top bar ── */}
      <header className="flex items-center justify-between px-8 py-6">
        <img src="/assets/vayn-logo.jpg" alt="VAYN" className="h-6 w-auto" />
        <span className="text-[9px] tracking-[0.3em] uppercase text-white/25">
          Active Roster
        </span>
      </header>

      {/* ── editorial header ── */}
      <div className="px-8 pb-12 pt-8 border-b border-white/5">
        <p className="text-[9px] tracking-[0.35em] uppercase text-white/25 mb-4">
          {new Date().getFullYear()} Collection
        </p>
        <h1 className="text-3xl sm:text-5xl font-thin tracking-widest uppercase text-white/90 leading-none">
          Our Talent
        </h1>
      </div>

      {/* ── layout: sidebar + grid ── */}
      <div className="flex flex-col lg:flex-row gap-0">

        {/* filters sidebar */}
        <aside className="lg:w-60 flex-shrink-0 px-8 py-10 border-r border-white/5">
          <p className="text-[9px] tracking-[0.3em] uppercase text-white/25 mb-8">
            Filter
          </p>

          <div className="space-y-8">
            <FilterSlider
              label="Height"
              unit="cm"
              min={155}
              max={195}
              value={minHeight}
              onChange={setMinHeight}
            />
            <FilterSlider
              label="Bust"
              unit="cm"
              min={75}
              max={105}
              value={minBust}
              onChange={setMinBust}
            />
            <FilterSlider
              label="Waist"
              unit="cm"
              min={55}
              max={85}
              value={minWaist}
              onChange={setMinWaist}
            />
          </div>

          {/* result count */}
          <p className="mt-10 text-[10px] tracking-[0.2em] text-white/20">
            {filtered.length} result{filtered.length !== 1 ? "s" : ""}
          </p>
        </aside>

        {/* grid */}
        <main className="flex-1 p-8">
          {loading && (
            <div className="flex items-center justify-center h-64">
              <span className="text-[10px] tracking-[0.3em] uppercase text-white/20 animate-pulse">
                Loading…
              </span>
            </div>
          )}

          {error && (
            <div className="flex items-center justify-center h-64">
              <p className="text-[11px] text-red-400/50 tracking-wide">{error}</p>
            </div>
          )}

          {!loading && !error && filtered.length === 0 && (
            <div className="flex items-center justify-center h-64">
              <p className="text-[11px] tracking-[0.2em] uppercase text-white/15">
                No models match current filters
              </p>
            </div>
          )}

          {!loading && !error && (
            <div
              className="grid gap-4"
              style={{
                gridTemplateColumns: "repeat(auto-fill, minmax(220px, 1fr))",
              }}
            >
              {filtered.map((model) => (
                <div key={model.modelId}>
                  <ModelCard model={model} />
                  {/* name below card */}
                  <p className="mt-2 text-[10px] tracking-[0.2em] uppercase text-white/40 font-light">
                    {model.name}
                  </p>
                </div>
              ))}
            </div>
          )}
        </main>
      </div>
    </div>
  );
}
