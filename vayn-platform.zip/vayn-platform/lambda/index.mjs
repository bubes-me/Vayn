/**
 * VAYN — Lambda Handler  (vayn-models-api/index.mjs)
 *
 * Routes:
 *   GET    /models                          → list models
 *   GET    /models?status=Active            → filtered list (public directory)
 *   POST   /models                          → create model
 *   PUT    /models/{modelId}                → update model
 *
 *   GET    /users                           → list all Cognito users + their groups (Admin only)
 *   POST   /users                           → create Cognito user + assign group (Admin only)
 *   PUT    /users/{username}/group          → change user's group (Admin only)
 *   PUT    /users/{username}/enable         → re-enable a disabled user (Admin only)
 *   PUT    /users/{username}/disable        → disable a user (Admin only)
 *   DELETE /users/{username}               → delete a user (Admin only)
 *
 * Env vars:
 *   TABLE_NAME      — DynamoDB table (default: VaynModels)
 *   USER_POOL_ID    — Cognito User Pool ID
 */

import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import {
  DynamoDBDocumentClient, ScanCommand, PutCommand, UpdateCommand,
} from "@aws-sdk/lib-dynamodb";
import {
  CognitoIdentityProviderClient,
  ListUsersCommand,
  AdminListGroupsForUserCommand,
  AdminCreateUserCommand,
  AdminAddUserToGroupCommand,
  AdminRemoveUserFromGroupCommand,
  AdminEnableUserCommand,
  AdminDisableUserCommand,
  AdminDeleteUserCommand,
} from "@aws-sdk/client-cognito-identity-provider";
import { randomUUID } from "crypto";

const dynamo    = DynamoDBDocumentClient.from(new DynamoDBClient({}));
const cognito   = new CognitoIdentityProviderClient({});
const TABLE     = process.env.TABLE_NAME   ?? "VaynModels";
const POOL_ID   = process.env.USER_POOL_ID ?? "";

/* ─── response helpers ────────────────────────────────────────── */
const corsHeaders = () => ({
  "Content-Type": "application/json",
  "Access-Control-Allow-Origin":  "*",
  "Access-Control-Allow-Headers": "Content-Type,Authorization",
  "Access-Control-Allow-Methods": "GET,POST,PUT,DELETE,OPTIONS",
});
const ok  = (body, status = 200) => ({ statusCode: status, headers: corsHeaders(), body: JSON.stringify(body) });
const err = (msg,  status = 400) => ({ statusCode: status, headers: corsHeaders(), body: JSON.stringify({ error: msg }) });

/* ─── auth helpers ────────────────────────────────────────────── */
function getGroups(event) {
  try {
    const claims = event.requestContext?.authorizer?.claims ?? {};
    const raw    = claims["cognito:groups"] ?? "";
    return Array.isArray(raw) ? raw : raw.split(",").filter(Boolean);
  } catch { return []; }
}
const isAdmin   = (g) => g.includes("Admin");
const isManager = (g) => g.includes("Admin") || g.includes("Talent Manager");

/* ═══════════════════════════════════════════════════════════════
   MODEL ROUTES
═══════════════════════════════════════════════════════════════ */
async function listModels(event) {
  const groups       = getGroups(event);
  const statusFilter = event.queryStringParameters?.status;
  if (!isManager(groups) && !statusFilter) return err("Forbidden", 403);

  const params = { TableName: TABLE };
  if (statusFilter) {
    params.FilterExpression           = "#s = :s";
    params.ExpressionAttributeNames   = { "#s": "status" };
    params.ExpressionAttributeValues  = { ":s": statusFilter };
  }
  const result = await dynamo.send(new ScanCommand(params));
  return ok({ items: result.Items });
}

async function createModel(event) {
  const groups = getGroups(event);
  const body   = JSON.parse(event.body ?? "{}");
  if (!body.name) return err("name is required");
  const isScout = groups.includes("Scout");
  if (!isScout && !isManager(groups)) return err("Forbidden", 403);

  const item = {
    modelId:       randomUUID(),
    name:          String(body.name).trim(),
    height_cm:     Number(body.height_cm) || 0,
    bust_cm:       Number(body.bust_cm)   || 0,
    waist_cm:      Number(body.waist_cm)  || 0,
    hips_cm:       Number(body.hips_cm)   || 0,
    status:        isScout ? "Pending Review" : (body.status ?? "Pending Review"),
    profileImageId: body.profileImageId ?? null,
    createdAt:     new Date().toISOString(),
  };
  await dynamo.send(new PutCommand({ TableName: TABLE, Item: item }));
  return ok(item, 201);
}

async function updateModel(event) {
  const groups  = getGroups(event);
  if (!isManager(groups)) return err("Forbidden", 403);
  const modelId = event.pathParameters?.modelId;
  if (!modelId) return err("modelId required");

  const body    = JSON.parse(event.body ?? "{}");
  const allowed = ["status", "height_cm", "bust_cm", "waist_cm", "hips_cm", "profileImageId"];
  const updates = []; const names = {}; const values = {};

  for (const field of allowed) {
    if (body[field] !== undefined) {
      names[`#${field}`]  = field;
      values[`:${field}`] = body[field];
      updates.push(`#${field} = :${field}`);
    }
  }
  if (!updates.length) return err("No valid fields to update");
  names["#updatedAt"]  = "updatedAt";
  values[":updatedAt"] = new Date().toISOString();
  updates.push("#updatedAt = :updatedAt");

  await dynamo.send(new UpdateCommand({
    TableName: TABLE, Key: { modelId },
    UpdateExpression: `SET ${updates.join(", ")}`,
    ExpressionAttributeNames: names, ExpressionAttributeValues: values,
  }));
  return ok({ modelId, updated: true });
}

/* ═══════════════════════════════════════════════════════════════
   USER ROUTES (Admin only)
═══════════════════════════════════════════════════════════════ */
async function listUsers(event) {
  if (!isAdmin(getGroups(event))) return err("Forbidden", 403);

  const usersRes = await cognito.send(new ListUsersCommand({ UserPoolId: POOL_ID }));

  /* fetch each user's group in parallel */
  const users = await Promise.all(
    usersRes.Users.map(async (u) => {
      const groupsRes = await cognito.send(
        new AdminListGroupsForUserCommand({ UserPoolId: POOL_ID, Username: u.Username })
      );
      const email = u.Attributes?.find((a) => a.Name === "email")?.Value ?? u.Username;
      return {
        username: u.Username,
        email,
        enabled:  u.Enabled,
        status:   u.UserStatus,
        group:    groupsRes.Groups?.[0]?.GroupName ?? null,
      };
    })
  );
  return ok({ users });
}

async function createUser(event) {
  if (!isAdmin(getGroups(event))) return err("Forbidden", 403);
  const { email, tempPassword, group } = JSON.parse(event.body ?? "{}");
  if (!email || !tempPassword || !group) return err("email, tempPassword and group are required");

  const created = await cognito.send(new AdminCreateUserCommand({
    UserPoolId:        POOL_ID,
    Username:          email,
    TemporaryPassword: tempPassword,
    UserAttributes:    [{ Name: "email", Value: email }, { Name: "email_verified", Value: "true" }],
    MessageAction:     "SUPPRESS", /* set to "RESEND" if you want Cognito to email them */
  }));

  await cognito.send(new AdminAddUserToGroupCommand({
    UserPoolId: POOL_ID,
    Username:   created.User.Username,
    GroupName:  group,
  }));

  return ok({ username: created.User.Username, email, group }, 201);
}

async function changeGroup(event) {
  if (!isAdmin(getGroups(event))) return err("Forbidden", 403);
  const username = decodeURIComponent(event.pathParameters?.username ?? "");
  const { oldGroup, newGroup } = JSON.parse(event.body ?? "{}");
  if (!username || !newGroup) return err("username and newGroup required");

  if (oldGroup) {
    await cognito.send(new AdminRemoveUserFromGroupCommand({ UserPoolId: POOL_ID, Username: username, GroupName: oldGroup }));
  }
  await cognito.send(new AdminAddUserToGroupCommand({ UserPoolId: POOL_ID, Username: username, GroupName: newGroup }));
  return ok({ username, group: newGroup });
}

async function enableUser(event) {
  if (!isAdmin(getGroups(event))) return err("Forbidden", 403);
  const username = decodeURIComponent(event.pathParameters?.username ?? "");
  await cognito.send(new AdminEnableUserCommand({ UserPoolId: POOL_ID, Username: username }));
  return ok({ username, enabled: true });
}

async function disableUser(event) {
  if (!isAdmin(getGroups(event))) return err("Forbidden", 403);
  const username = decodeURIComponent(event.pathParameters?.username ?? "");
  await cognito.send(new AdminDisableUserCommand({ UserPoolId: POOL_ID, Username: username }));
  return ok({ username, enabled: false });
}

async function deleteUser(event) {
  if (!isAdmin(getGroups(event))) return err("Forbidden", 403);
  const username = decodeURIComponent(event.pathParameters?.username ?? "");
  await cognito.send(new AdminDeleteUserCommand({ UserPoolId: POOL_ID, Username: username }));
  return ok({ username, deleted: true });
}

/* ═══════════════════════════════════════════════════════════════
   ROUTER
═══════════════════════════════════════════════════════════════ */
export async function handler(event) {
  if (event.httpMethod === "OPTIONS") return { statusCode: 204, headers: corsHeaders(), body: "" };

  const method   = event.httpMethod;
  const path     = event.resource ?? event.path ?? "";

  try {
    /* models */
    if (method === "GET"  && path.includes("/models") && !path.includes("{modelId}")) return listModels(event);
    if (method === "POST" && path.endsWith("/models"))                                 return createModel(event);
    if (method === "PUT"  && path.includes("/models/{modelId}"))                       return updateModel(event);

    /* users */
    if (method === "GET"    && path.endsWith("/users"))                        return listUsers(event);
    if (method === "POST"   && path.endsWith("/users"))                        return createUser(event);
    if (method === "PUT"    && path.endsWith("/group"))                        return changeGroup(event);
    if (method === "PUT"    && path.endsWith("/enable"))                       return enableUser(event);
    if (method === "PUT"    && path.endsWith("/disable"))                      return disableUser(event);
    if (method === "DELETE" && path.includes("/users/{username}"))             return deleteUser(event);

    return err("Not Found", 404);
  } catch (e) {
    console.error(e);
    return err("Internal Server Error", 500);
  }
}
