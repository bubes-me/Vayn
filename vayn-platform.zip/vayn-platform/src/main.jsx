/**
 * VAYN — main.jsx
 *
 * Entry point. Configures AWS Amplify (v6), then renders the
 * top-level App which handles the three views:
 *
 *   1. AuthView   — pre-login (unauthenticated)
 *   2. Dashboard  — post-login internal (Admin, Talent Manager, Scout)
 *   3. DirectoryGrid — public-facing (always accessible via /directory route)
 *
 * ─── Setup ────────────────────────────────────────────────────────────────
 *
 * 1. Install dependencies:
 *      npm install aws-amplify
 *      npm install -D tailwindcss postcss autoprefixer
 *      npx tailwindcss init -p
 *
 * 2. Fill in the VAYN_CONFIG object below with your real AWS resource IDs.
 *
 * 3. In tailwind.config.js set content: ["./index.html","./src/**\/*.{js,jsx}"]
 *
 * 4. index.css (imported below):
 *      @tailwind base;
 *      @tailwind components;
 *      @tailwind utilities;
 *
 * 5. Build & deploy static output to GitHub Pages:
 *      npm run build → dist/
 */

import React, { useState, useEffect } from "react";
import ReactDOM from "react-dom/client";
import { Amplify } from "aws-amplify";
import { getCurrentUser, fetchAuthSession, signOut } from "aws-amplify/auth";

import AuthView     from "./components/AuthView.jsx";
import Dashboard    from "./components/Dashboard.jsx";
import DirectoryGrid from "./components/DirectoryGrid.jsx";

import "./index.css";

/* ─── ⚙️  CONFIGURATION — fill these in ──────────────────────── */

const VAYN_CONFIG = {
  /* Cognito */
  cognitoUserPoolId:     "us-east-1_XXXXXXXXX",
  cognitoUserPoolClientId: "XXXXXXXXXXXXXXXXXXXXXXXXXX",
  cognitoRegion:         "us-east-1",

  /* API Gateway — prod stage URL */
  apiBase: "https://XXXXXXXXXX.execute-api.us-east-1.amazonaws.com/prod",
};

/* ─── Amplify v6 configuration ────────────────────────────────── */

Amplify.configure({
  Auth: {
    Cognito: {
      userPoolId:       VAYN_CONFIG.cognitoUserPoolId,
      userPoolClientId: VAYN_CONFIG.cognitoUserPoolClientId,
      region:           VAYN_CONFIG.cognitoRegion,
    },
  },
});

/* ─── role extractor ──────────────────────────────────────────── */

async function getRole() {
  try {
    const session = await fetchAuthSession();
    const payload = session.tokens?.accessToken?.payload ?? {};
    const groups  = payload["cognito:groups"] ?? [];
    if (groups.includes("Admin"))          return "Admin";
    if (groups.includes("Talent Manager")) return "Talent Manager";
    if (groups.includes("Scout"))          return "Scout";
    return "Unauthorized";
  } catch {
    return null;
  }
}

/* ─── simple hash-based view router ──────────────────────────── */

function useRoute() {
  const [route, setRoute] = useState(window.location.hash || "#app");
  useEffect(() => {
    const handler = () => setRoute(window.location.hash || "#app");
    window.addEventListener("hashchange", handler);
    return () => window.removeEventListener("hashchange", handler);
  }, []);
  return route;
}

/* ─── root app ────────────────────────────────────────────────── */

function App() {
  const route = useRoute();

  const [authUser,    setAuthUser]    = useState(null);  // Amplify user object
  const [authToken,   setAuthToken]   = useState(null);  // raw JWT string
  const [role,        setRole]        = useState(null);  // Cognito group
  const [checking,    setChecking]    = useState(true);  // initial session check

  /* restore session on mount */
  useEffect(() => {
    (async () => {
      try {
        const user    = await getCurrentUser();
        const session = await fetchAuthSession();
        const token   = session.tokens?.accessToken?.toString() ?? null;
        const r       = await getRole();
        setAuthUser(user);
        setAuthToken(token);
        setRole(r);
      } catch {
        /* not authenticated — stay on auth view */
      } finally {
        setChecking(false);
      }
    })();
  }, []);

  /* callback from AuthView after successful Cognito sign-in */
  async function handleAuth(user, resolvedRole) {
    const session = await fetchAuthSession();
    const token   = session.tokens?.accessToken?.toString() ?? null;
    setAuthUser(user);
    setAuthToken(token);
    setRole(resolvedRole);
  }

  /* sign out */
  async function handleSignOut() {
    await signOut();
    setAuthUser(null);
    setAuthToken(null);
    setRole(null);
  }

  /* ── splash while checking session ── */
  if (checking) {
    return (
      <div className="min-h-screen bg-[#0a0a0a] flex items-center justify-center">
        <img
          src="/assets/vayn-logo.jpg"
          alt="VAYN"
          className="h-6 w-auto opacity-20 animate-pulse"
        />
      </div>
    );
  }

  /* ── public directory (hash-routed, no auth required) ── */
  if (route === "#directory") {
    return (
      <DirectoryGrid
        apiBase={VAYN_CONFIG.apiBase}
        authToken={authToken} /* pass token if your public endpoint is behind auth */
      />
    );
  }

  /* ── authenticated internal views ── */
  if (authUser && role) {
    return (
      <Dashboard
        role={role}
        user={authUser}
        apiBase={VAYN_CONFIG.apiBase}
        authToken={authToken}
        onSignOut={handleSignOut}
      />
    );
  }

  /* ── unauthenticated → login ── */
  return <AuthView onAuth={handleAuth} />;
}

/* ─── mount ───────────────────────────────────────────────────── */

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
